# What is Stocks of Coins?

Stocks of Coins is a mathematical Game of Strategy in which two Opponents take Turns removing Objects from distinct Heaps or Rows.
In this Variant on each Turn, a Player and the PC Computer must remove/take any Number of Coins' Stack from one Row alternately.
The one, who takes the last Stack of Coins loses.

Good luck, and have fun!!!


# How Players can ask Questions or make Comments??

For all additional Information about the Game, but also if You want to send Bug Report, to provide a Suggestion(s), or to share Your Idea(s),
You can write Me to Email given below (English only, please).


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
| Anton Vrdoljak, M.Sc.		|
|				|
| Department of Mathematics	|
| Faculty of Civil Engineering	|
| University of Mostar		|
|				|
| anton.vrdoljak@gf.sum.ba	|
|				|
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~